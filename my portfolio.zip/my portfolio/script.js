document.getElementById('contactForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Stop the form from submitting
  alert('Message sent! (Not really, but this is a demo)');
});
